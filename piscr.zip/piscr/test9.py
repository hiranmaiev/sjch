from transformers import AutoModel, AutoTokenizer

# Specify the model name for the BERT Scholar model
model_name = 'gsarti/bert-scholarly'

# Download the model and tokenizer
model = AutoModel.from_pretrained(model_name)
tokenizer = AutoTokenizer.from_pretrained(model_name)

# Specify the directory where you want to save the model and tokenizer
save_directory = './bert_scholarly_model'

# Save the model and tokenizer locally
model.save_pretrained(save_directory)
tokenizer.save_pretrained(save_directory)

# Load the model and tokenizer from the local directory to verify
loaded_model = AutoModel.from_pretrained(save_directory)
loaded_tokenizer = AutoTokenizer.from_pretrained(save_directory)

print("BERT Scholar model and tokenizer loaded successfully from local directory.")
